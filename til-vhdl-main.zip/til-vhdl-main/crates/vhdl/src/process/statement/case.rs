#[derive(Debug, Clone, PartialEq, Eq, Hash)]
/// TODO: Implement case/when
///
/// (Note that this is fairly involved, and not currently necessary.)
pub struct Case {}
